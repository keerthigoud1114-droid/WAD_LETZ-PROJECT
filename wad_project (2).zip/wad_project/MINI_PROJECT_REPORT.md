# MINI PROJECT REPORT

# BREWBOARD: ZEROQUEUE CANTEEN HACK
### A Touch-Friendly Campus Canteen Ordering & Live Token Dispatch System

**A Mini Project submitted to**  
**MRTC (MRV) - Hyderabad**  
*in partial fulfillment of the requirements for the award of the degree of*  
**BACHELOR OF TECHNOLOGY**  
**in**  
**Department of Computer Science and Engineering**

**Submitted by:**

- **Roll No: 26MVCSCR0025 – MATAM SRIVARSHINI**
- **Roll No: 26MVCSCR0026 – MOHAMMED NOMAAN RUSTUM**
- **Roll No: 26MVCSCR0027 – NADIMINTI SAI KEERTHANA**

<br>

**MALLA REDDY TECHNICAL CAMPUS**  
*A Constituent Unit of*  
**MALLA REDDY VISHWAVIDYAPEETH**  
*(Deemed to be University)*  
Approved by UGC & AICTE - New Delhi  
Maisammaguda, Medchal (Dist), Hyderabad - 500100, Telangana  
**Academic Year: 2026 – 2027**

---

## CERTIFICATE

This is to certify that the mini project report entitled **"BrewBoard: ZeroQueue Canteen Hack"** is a bonafide work carried out by:
- **MATAM SRIVARSHINI** (Reg. No. **26MVCSCR0025**)
- **MOHAMMED NOMAAN RUSTUM** (Reg. No. **26MVCSCR0026**)
- **NADIMINTI SAI KEERTHANA** (Reg. No. **26MVCSCR0027**)

in partial fulfillment of the requirements for the course **Web Application Development Laboratory** of the **Department of Computer Science and Engineering**, **MALLA REDDY TECHNICAL CAMPUS**, during the academic year **2026 – 2027**.

<br><br>

_____________________________ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; _____________________________  
**Project Guide** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; **Head of the Department**  
Department of CSE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Department of CSE  
Malla Reddy Technical Campus &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Malla Reddy Technical Campus  

---

## DECLARATION

We hereby declare that the mini project report entitled **"BrewBoard: ZeroQueue Canteen Hack"** submitted to **MALLA REDDY TECHNICAL CAMPUS** is a record of original work done by us under the guidance of our Project Guide, Assistant Professor, Department of Computer Science and Engineering. The work has not been submitted to any other university or institute for the award of any degree or diploma.

1. **MATAM SRIVARSHINI** (Reg. No: **26MVCSCR0025**)  
   Signature: __________________________ &nbsp;&nbsp;&nbsp;&nbsp; Date: 20-11-2026  

2. **MOHAMMED NOMAAN RUSTUM** (Reg. No: **26MVCSCR0026**)  
   Signature: __________________________ &nbsp;&nbsp;&nbsp;&nbsp; Date: 20-11-2026  

3. **NADIMINTI SAI KEERTHANA** (Reg. No: **26MVCSCR0027**)  
   Signature: __________________________ &nbsp;&nbsp;&nbsp;&nbsp; Date: 20-11-2026  

---

## ACKNOWLEDGEMENT

We express our sincere gratitude to our project guide, Assistant Professor, Department of Computer Science and Engineering, for the valuable guidance, constant encouragement, and continuous support throughout this project.

We thank the **Head of the Department**, Department of Computer Science and Engineering, and **Dr. Selvamani Indrajith**, Associate Dean of **Malla Reddy Technical Campus**, for providing the facilities and academic support required to complete this work.

We also thank our faculty members, family, and friends for their help and motivation.

---

## ABSTRACT

College canteens and campus cafes experience massive, chaotic crowding during short 15-minute lecture breaks and lunch hours. Hundreds of hungry students jostle at billing counters simultaneously, resulting in lost order slips, incorrect change calculations, and students missing classes while waiting for food. Canteen staff face immense stress handling physical cash and shouting order numbers in noisy cafeterias.

To solve this problem, **"BrewBoard: ZeroQueue Canteen Hack"** was developed as a responsive, touch-friendly web application utilizing pure client-side web technologies: **HTML5**, **CSS3**, and modern vanilla **JavaScript (ES6+)**. The system introduces a streamlined, zero-login student kiosk interface displaying 20 staple campus foods and drinks with rich visual cards and dynamic customizations (size variations, sweetness, and add-ons like extra cheese or scoops). The application supports fast simulated digital transactions via dynamic UPI QR generation and student prepaid ID card tap-to-pay balances. 

Upon checkout, a sequential token dispatch engine assigns a unique alphanumeric token cached in browser `localStorage`, ensuring students never lose their receipts in basement cellular dead zones. The canteen staff manages queue throughput via a dedicated Kitchen Order Ticket (KOT) console, which synchronizes instantly with a high-contrast Live Wall Pickup Board featuring "Now Preparing" and "Ready for Pickup" columns, accompanied by automated Web Speech API voice announcements and Web Audio chime alerts. The project eliminates cafeteria bottlenecks and achieves complete digital canteen workflow automation.

**Keywords:** HTML5, CSS3, JavaScript, Web Speech API, LocalStorage, Canteen Kiosk, Token Dispatcher.

---

## TABLE OF CONTENTS

| Section | Title | Page No. |
| :--- | :--- | :---: |
| | **CERTIFICATE** | ii |
| | **DECLARATION** | iii |
| | **ACKNOWLEDGEMENT** | iv |
| | **ABSTRACT** | v |
| | **TABLE OF CONTENTS** | vi |
| **CHAPTER 1** | **SOFTWARE REQUIREMENTS** | **1** |
| 1.1 | Operating System | 1 |
| 1.2 | Programming Languages | 1 |
| 1.3 | Tools / IDE Used | 2 |
| 1.4 | Libraries and Packages | 2 |
| 1.5 | Hardware Requirements | 3 |
| **CHAPTER 2** | **SYSTEM DESIGN** | **4** |
| 2.1 | Overview of the System | 4 |
| 2.2 | Block Diagram | 5 |
| 2.3 | Algorithm | 5 |
| 2.4 | Flowchart | 6 |
| 2.5 | Modules of the System | 6 |
| **CHAPTER 3** | **IMPLEMENTATION** | **7** |
| 3.1 | Working of the Project | 7 |
| 3.2 | How to Run the Program | 8 |
| **CHAPTER 4** | **RESULTS AND CONCLUSION** | **9** |
| 4.1 | Results (Code and Output Screenshots) | 9 |
| 4.2 | Test Cases | 10 |
| 4.3 | Conclusion | 11 |

---

# CHAPTER 1: SOFTWARE REQUIREMENTS

### 1.1 Operating System
The project was developed and tested on **Microsoft Windows 11 (64-bit)**. Because the application is constructed entirely with standard web technologies, it is fully platform-independent and can run smoothly on Windows 10/11, Linux distributions (e.g., Ubuntu 22.04 LTS), macOS, Android Chrome, and iOS Safari.

### 1.2 Programming Languages
- **HTML5:** Utilized for building semantic markup, modular screen views (Student Kiosk, Kitchen Console, Wall Display, Wallet), modal overlays, and touch-friendly control elements.
- **CSS3:** Utilized for modern responsive kiosk styling, responsive CSS Grid and Flexbox layouts, custom variables for color themes, smooth modal animations, and high-visibility typography for cafeteria displays.
- **JavaScript (ES6+):** Utilized for complete client-side application logic, dynamic cart calculations, sequential token dispatch algorithms, browser `localStorage` state synchronization, Web Audio API tone synthesis, and Web Speech API automated announcements.
*Reason for Choice:* HTML5, CSS3, and modern vanilla JavaScript execute natively in any modern browser without requiring compilation, complex node package installations, or external hosting overhead.

### 1.3 Tools / IDE Used
- **Visual Studio Code (v1.95+):** Primary Integrated Development Environment for code editing and project organization.
- **VS Code Live Server Extension (v5.7+):** Provided a local HTTP server with automatic page reloading on changes for rapid multi-device testing.
- **Google Chrome DevTools (v120+):** Employed for responsive viewport emulation, touch event testing, console logging, and inspecting `localStorage` state.
- **Git & GitHub:** Used for source code version tracking and team collaboration.

### 1.4 Libraries and Packages

#### Table 1.1: Libraries and Browser APIs used in the project
| Library / API | Version | Purpose |
| :--- | :--- | :--- |
| **QRCode.js** | v1.0.0 (CDN / Local fallback) | Generates dynamic scannable UPI QR codes containing the merchant VPA and dynamic payable sum. |
| **Web Speech API** | Built-in Browser API (`speechSynthesis`) | Generates real-time automated speech announcements (*"Token 35 is ready at Counter 1"*) without external API subscriptions. |
| **Web Audio API** | Built-in Browser API (`AudioContext`) | Synthesizes clean dual-tone notification chimes when orders transition to ready state. |
| **Web Storage API** | Built-in Browser API (`localStorage`) | Persists active menu catalogs, out-of-stock toggles, active orders, and student wallet balances across page reloads. |
| **Google Fonts (Outfit & Inter)** | Web Font CDN | Provides clean, modern typography for kiosk touch readability and canteen wall visibility. |

### 1.5 Hardware Requirements

#### Table 1.2: Hardware requirements
| Component | Minimum Requirement | Recommended Specification |
| :--- | :--- | :--- |
| **Processor** | Intel Core i3 (2.0 GHz or higher) | Intel Core i5 / AMD Ryzen 5 or higher |
| **RAM** | 4 GB | 8 GB or higher |
| **Hard disk space** | 500 MB free space | 1 GB SSD free space |
| **Display / Other** | 1024 × 768 resolution, Keyboard, Mouse / Touch Screen | 1920 × 1080 Full HD Touch Kiosk / Smart TV Display, Speakers |

---

# CHAPTER 2: SYSTEM DESIGN

### 2.1 Overview of the System
**BrewBoard: ZeroQueue Canteen Hack** is an automated campus cafeteria workflow management system designed to eliminate congestion during short lecture breaks. 

- **Input:** The student browses 20 staple campus food items on a touch-friendly kiosk, configures optional sizes and add-ons (extra cheese, sugar levels, milk preference), selects immediate ordering or pre-schedules lunch rush slots, and authorizes payment via simulated UPI QR or Student Prepaid ID Card.
- **Process:** The JavaScript application engine computes total costs, generates a sequential token number with category prefixes (`#B-` for beverages, `#F-` for food), estimates kitchen preparation time based on current backlog, and synchronizes the state into `localStorage`.
- **Output:** The student receives an instant digital token receipt with an active countdown timer. Simultaneously, the order appears on the **Kitchen Order Ticket (KOT) Console**. When kitchen staff marks the order as "Ready", the token shifts to the green column of the **Live Canteen Wall Pickup Display**, triggering an audible chime and automated synthesized voice announcement across the cafeteria.

### 2.2 Block Diagram

```
+-----------------------------------------------------------------------------------+
|                            BREWBOARD CLIENT BROWSER                              |
+-----------------------------------------------------------------------------------+
       |                                                                      ^
       | 1. Touch Selection & Add-Ons                                         | 7. Audio Chime &
       v                                                                      |    Voice Announce
+-------------------------+     2. Item & Add-On Totals     +-------------------------------+
|  STUDENT KIOSK MENU     | ------------------------------> |   CENTRAL CART & ORDER ENGINE |
| (Photo Cards, Filters)  |                                 |   - Price Calculation Matrix  |
+-------------------------+                                 |   - Rush Hour Slot Scheduler  |
       |                                                    +-------------------------------+
       | 3. Checkout Trigger                                                  |
       v                                                                      v 4. Issue Token
+-------------------------+     Payment Signal (Mock UPI / Wallet)  +-------------------------------+
| PAYMENT CHECKOUT ENGINE | --------------------------------------> |  SEQUENTIAL TOKEN DISPATCHER  |
| - Mock UPI Dynamic QR   |                                         |  - Alphanumeric Token Gen     |
| - Student ID Tap-to-Pay |                                         |  - Prep Time Heuristics       |
+-------------------------+                                         +-------------------------------+
                                                                              |
                                     +----------------------------------------+
                                     | 5. Synchronized State (LocalStorage & Custom Events)
                                     v
       +---------------------------------------------+------------------------------------+
       |                                             |                                    |
       v                                             v                                    v
+-------------------------------+   +-------------------------------+   +-------------------------------+
| KITCHEN ORDER CONSOLE (KOT)   |   | LIVE CANTEEN WALL DISPLAY     |   | DIGITAL STUDENT TOKEN RECEIPT |
| - Mark In-Progress / Ready    |   | - Column: "Now Preparing"     |   | - Live Prep Countdown Timer   |
| - Rush Sold-Out Item Toggles  |   | - Column: "Ready for Pickup"  |   | - Offline Resilient Receipt   |
+-------------------------------+   +-------------------------------+   +-------------------------------+
```
**Fig 2.1: System Architecture and Data Flow Block Diagram**

### 2.3 Algorithm

#### Main System Algorithm:
- **Step 1:** Start.
- **Step 2:** Load menu items and student wallet balance from `localStorage` (or load default 20 college staple foods if first launch).
- **Step 3:** Render touch menu cards with categories: *All, Snacks, Beverages, Breakfast, Meals*.
- **Step 4:** On tapping an item card, verify inventory flag (`isAvailable`). If unavailable, alert that the item is sold out during rush hour; otherwise, open Customization Modal.
- **Step 5:** Read user selections: portion size, sweetness, add-ons (extra cheese, ice cream scoop, extra butter).
- **Step 6:** Compute dynamic price = `BasePrice + SizeDifference + Sum(SelectedAddons)`.
- **Step 7:** Add configured item to cart and refresh floating cart summary.
- **Step 8:** On checkout, select payment method:
  - If **Student Wallet**: Verify `WalletBalance >= CartTotal`. If valid, deduct balance; otherwise, display insufficient balance warning.
  - If **Mock UPI QR**: Generate dynamic QR using `QRCode.js` and simulate a 3-second auto-approval timer.
- **Step 9:** Generate sequential token (e.g., `#B-12` or `#F-28`) and calculate preparation duration heuristic.
- **Step 10:** Store order record in `localStorage` under active queue and trigger audio chime.
- **Step 11:** Display Digital Token Receipt with live countdown timer to the student.
- **Step 12:** Kitchen staff views order in KOT Console; clicking "Ready" advances order status to "Ready for Pickup".
- **Step 13:** Trigger Web Speech API voice notification and update Live Canteen Wall Board.
- **Step 14:** Stop.

### 2.4 Flowchart

```
                 ( Start )
                     |
                     v
            [ Browse Menu Items ]
                     |
                     v
           { Item in Stock? }
              /           \
       (No)  /             \ (Yes)
            v               v
    [ Show Sold Out ]   [ Select Size & Add-ons ]
            |               |
            |               v
            |       [ Add to Cart ]
            |               |
            |               v
            |       { Proceed to Pay? }
            |          /         \
            |   (Wallet)          (UPI QR)
            |      |                  |
            |   { Balance >= Total? } [ Display Dynamic QR ]
            |      /       \          [ 3-sec Simulated Auto-Pay ]
            |  (No)         (Yes)     |
            |   v             \       /
            | [ Alert Error ]  v     v
            |        \---> [ Payment Success ]
            |                      |
            |                      v
            |             [ Generate Token # ]
            |                      |
            |                      v
            |             [ Save to LocalStorage ]
            |                      |
            |                      v
            |             [ Show Digital Token Receipt ]
            |                      |
            |                      v
            |       +------------------------------+
            |       | Live Screen: "Now Preparing" |
            |       +------------------------------+
            |                      |
            |                      v
            |       [ Kitchen Staff Taps "Ready" ]
            |                      |
            |                      v
            |       +------------------------------+
            |       | Live Screen: "Ready Pickup"  |
            |       +------------------------------+
            |                      |
            |                      v
            |       [ Play Chime & Speak Token # ]
            |                      |
            |                      v
            +-----------------> ( Stop )
```
**Fig 2.2: Order Placement and Kitchen Token Dispatch Flowchart**

### 2.5 Modules of the System

#### Table 2.1: Modules of the project
| Module | Description |
| :--- | :--- |
| **Kiosk Menu & Category Module** | Displays responsive touch cards for 20 college staple items with instant search and category filtering (Breakfast, Snacks, Meals, Beverages). |
| **Dynamic Customization Module** | Handles size variations (Regular / Large) and custom add-ons (Extra Cheese, Less Sugar, Milk options) with real-time price updates. |
| **Cart & Pre-Booking Module** | Manages order quantities, calculates subtotal, taxes, and provides time-slot pre-booking for hot lunch breaks (e.g., 1:15 PM). |
| **Mock Checkout & Payment Module** | Generates dynamic UPI QR codes with simulated 3-second auto-approval and manages prepaid Student ID Card balance deductions. |
| **Sequential Token Dispatcher** | Assigns categorized sequential tokens (`#B-` for beverages, `#F-` for food) and computes preparation wait times based on kitchen load. |
| **Live Canteen Wall Display Board** | High-contrast cafeteria screen separating active orders into "Now Preparing" and "Ready for Pickup" columns. |
| **Kitchen Order Ticket (KOT) Console** | Staff touch interface to monitor incoming tickets, advance orders from 'Preparing' to 'Ready' with one tap, and toggle rush-hour sold-out items. |
| **Audio Alert & Speech Module** | Dual-tone chime generator using Web Audio API paired with Web Speech API text-to-speech for audible cafeteria token callouts. |

---

# CHAPTER 3: IMPLEMENTATION

### 3.1 Working of the Project
When the web application is opened in a browser:
1. **Initial Screen (Student Kiosk):** The student is welcomed by a visual kiosk menu displaying food cards with images, prices, veg/egg indicators, and preparation times. Students can switch categories with a single tap without any mandatory login or registration.
2. **Item Customization:** Tapping on an item (e.g., *Cold Coffee*, ₹40) opens the customization modal. Choosing *Large (+₹15)* and *Extra Ice Cream (+₹15)* recalculates the price to ₹70 instantly.
3. **Cart Review & Checkout:** Tapping the cart button displays all selected items, add-on summaries, and subtotal. Students can choose to pre-schedule hot lunch pickup for fixed break times (e.g., 1:15 PM) or order immediately.
4. **Digital Payment Execution:** 
   - When paying via UPI QR, `QRCode.js` renders a dynamic scannable QR code. A simulated 3-second progress indicator verifies payment automatically.
   - When paying via Student Card, the system checks whether the mock card balance covers the order total and deducts the amount instantly.
5. **Token Generation & Storage:** A sequential token number (e.g., `#B-42`) is generated and saved into `localStorage`. A digital receipt appears with an animated preparation countdown timer.
6. **Kitchen & Wall Board Synchronization:** Kitchen staff switches to the **Kitchen Console** tab, where Token `#B-42` appears in the "Preparing" queue. Tapping "Mark Ready" shifts the token to the green "Ready for Pickup" column on the **Live Canteen Display**, triggers a chime, and synthesizes the audio announcement: *"Token 42 is ready for pickup at Counter 1"*.

### 3.2 How to Run the Program
1. **Step 1:** Download or clone the project directory `wad_project` to your local system.
2. **Step 2:** Ensure the three core files (`index.html`, `style.css`, and `script.js`) alongside the `assets/` folder are located in the same root directory.
3. **Step 3:** Open the folder in **Visual Studio Code**.
4. **Step 4:** Right-click `index.html` and select **"Open with Live Server"**, or open `index.html` directly in any web browser (Google Chrome, Microsoft Edge, Mozilla Firefox).
5. **Step 5:** Use the top navigation bar to test the **Student Kiosk**, **Kitchen Console**, **Live Pickup Board**, and **Student Wallet** views.

---

# CHAPTER 4: RESULTS AND CONCLUSION

### 4.1 Results (Code and Output Screenshots)

#### Output Screen 1: Touch-Friendly Kiosk Menu Interface
```
+-----------------------------------------------------------------------------------+
|  CAMPUS QUICK BITE  [Student Kiosk] [Kitchen Console] [Live Display] [Wallet]     |
+-----------------------------------------------------------------------------------+
|  CATEGORIES:  (ALL)   [Snacks]   [Beverages]   [Breakfast]   [Meals]              |
|                                                                                   |
|  +--------------------+  +--------------------+  +--------------------+           |
|  | [Samosa Photo]     |  | [Cold Coffee]      |  | [Masala Maggi]     |           |
|  | Samosa (2 pcs)     |  | Cold Coffee Brew   |  | Hot Masala Maggi   |           |
|  | Veg * 3 mins       |  | Veg * 2 mins       |  | Veg * 5 mins       |           |
|  | Rs. 20             |  | Rs. 40             |  | Rs. 35             |           |
|  | [+ Customize]      |  | [+ Customize]      |  | [+ Customize]      |           |
|  +--------------------+  +--------------------+  +--------------------+           |
|                                                     [ Floating Cart: 2 Items | Rs.55 ]|
+-----------------------------------------------------------------------------------+
```
**Fig 4.1: Touch-Optimized Student Kiosk Menu Screen**  
*Description: Displays large food cards with preparation times, prices, and one-tap customization triggers allowing students to order in under 30 seconds.*

#### Output Screen 2: Customization Modal and Mock UPI QR Payment
```
+-------------------------------------------------------+
|  CUSTOMIZE: Cold Coffee                               |
+-------------------------------------------------------+
|  Select Size:      (o) Regular (Rs.40)   ( ) Large (+Rs.15) |
|  Sweetness Level:  ( ) Standard          (o) Less Sugar     |
|  Add-ons:          [X] Extra Ice Cream Scoop (+Rs.15)        |
|                    [ ] Chocolate Drizzle (+Rs.10)           |
|                                                       |
|  Total Price: Rs. 55.00                               |
|  [ Cancel ]                        [ Add to Order ]   |
+-------------------------------------------------------+
```
**Fig 4.2: Dynamic Customization and Add-On Configuration Screen**  
*Description: Provides real-time dynamic pricing calculation for sizes and add-ons before adding items to the checkout cart.*

#### Output Screen 3: Live Canteen Wall Token Pickup Display
```
+-----------------------------------------------------------------------------------+
|                        CANTEEN LIVE ORDER STATUS BOARD                            |
+-----------------------------------------+-----------------------------------------+
|      NOW PREPARING (Cooking...)         |       READY FOR PICKUP (Counter 1)      |
+-----------------------------------------+-----------------------------------------+
|   +---------------------------------+   |   +---------------------------------+   |
|   |         TOKEN #B-32             |   |   |         TOKEN #F-28             |   |
|   |   Chai & Samosa (Est. 2m left)  |   |   |   Cheese Sandwich (COLLECT NOW) |   |
|   +---------------------------------+   |   +---------------------------------+   |
|   +---------------------------------+   |   +---------------------------------+   |
|   |         TOKEN #F-33             |   |   |         TOKEN #B-30             |   |
|   |   Veg Puff (Est. 4m left)       |   |   |   Cold Coffee (COLLECT NOW)     |   |
|   +---------------------------------+   |   +---------------------------------+   |
+-----------------------------------------+-----------------------------------------+
```
**Fig 4.3: High-Contrast Live Token Pickup Board Screen**  
*Description: Displays large split columns for preparing versus ready tokens, synchronized with automated Web Speech API voice announcements.*

### 4.2 Test Cases

#### Table 4.1: Test cases and verification results
| No. | Input Scenario | Expected Output | Actual Output | Result |
| :---: | :--- | :--- | :--- | :---: |
| **1** | Select Samosa (₹20), tap "Add" | Item added to cart, cart badge increments to 1, total ₹20 | Cart count becomes 1, subtotal ₹20 | **Pass** |
| **2** | Cold Coffee (₹40) + Large (+₹15) + Extra Ice Cream (+₹15) | Total calculated = ₹70 | Total dynamically calculated as ₹70 | **Pass** |
| **3** | Student Card tap-to-pay with ₹200 balance, order ₹60 | Balance deducted to ₹140, payment confirmed, token generated | Balance updated to ₹140, Token issued | **Pass** |
| **4** | Student Card payment with ₹30 balance, order ₹80 | Payment rejected, error prompt displayed | Error message shown; transaction blocked | **Pass** |
| **5** | Choose Mock UPI QR payment | Dynamic QR code generated; simulated auto-approval after 3s | QR code generated, auto-approves after 3s | **Pass** |
| **6** | Sequential token issuance for food and drink | Tokens prefixed correctly (e.g., `#B-01`, `#F-02`) | Sequential tokens assigned correctly | **Pass** |
| **7** | Kitchen staff taps "Ready" on active token | Token moves to "Ready for Pickup" column; chime & TTS voice play | Token transitioned; audio and TTS announced | **Pass** |
| **8** | Staff toggles item to "Out of Stock" | Item disabled on Kiosk; click shows sold-out alert | Item disabled; cannot be added to cart | **Pass** |

### 4.3 Conclusion
**BrewBoard: ZeroQueue Canteen Hack** successfully resolves the chaos, lost slips, and long waiting lines in college canteens during short lecture breaks. Built exclusively with **HTML5**, **CSS3**, and vanilla **JavaScript**, the application provides a responsive self-service kiosk, dynamic item customizer, mock UPI and student card payments, automated sequential token generation, a kitchen management console, and an audible real-time pickup board. LocalStorage caching ensures offline resiliency in basement cafeterias. Developing this project provided comprehensive hands-on proficiency in modern DOM manipulation, asynchronous timer patterns, client-side state synchronization, and the native Web Speech and Web Audio APIs.
