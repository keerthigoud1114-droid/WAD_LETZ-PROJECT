const test = require('node:test');
const assert = require('node:assert/strict');

function sanitizeText(input) {
  if (typeof input !== 'string') return '';
  return input
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;')
    .trim();
}

function validateWalletTopup(amount) {
  const num = Number(amount);
  if (isNaN(num) || !isFinite(num)) {
    return { valid: false, error: 'Amount must be a numeric value' };
  }
  if (num < 10) {
    return { valid: false, error: 'Minimum top-up is ₹10' };
  }
  if (num > 5000) {
    return { valid: false, error: 'Maximum single top-up is ₹5000' };
  }
  return { valid: true, amount: Math.round(num * 100) / 100 };
}

function validateItemQuantity(qty) {
  const parsed = parseInt(qty, 10);
  if (isNaN(parsed) || parsed < 1) return 1;
  if (parsed > 20) return 20;
  return parsed;
}

test('Validation - Sanitizes potential HTML injection in search or names', () => {
  const dirty = '<script>alert("xss")</script>Samosa';
  const clean = sanitizeText(dirty);
  assert.equal(clean.includes('<script>'), false);
  assert.equal(clean.includes('&lt;script&gt;'), true);
});

test('Validation - Rejects invalid or negative wallet top-up amounts', () => {
  assert.equal(validateWalletTopup(-50).valid, false);
  assert.equal(validateWalletTopup(0).valid, false);
  assert.equal(validateWalletTopup('abc').valid, false);
  assert.equal(validateWalletTopup(5).valid, false);
});

test('Validation - Accepts legitimate top-up bounds between 10 and 5000', () => {
  assert.equal(validateWalletTopup(100).valid, true);
  assert.equal(validateWalletTopup(500).valid, true);
  assert.equal(validateWalletTopup(10).valid, true);
  assert.equal(validateWalletTopup(5000).valid, true);
  assert.equal(validateWalletTopup(6000).valid, false);
});

test('Validation - Constrains item quantities within 1 to 20 range', () => {
  assert.equal(validateItemQuantity(-5), 1);
  assert.equal(validateItemQuantity(0), 1);
  assert.equal(validateItemQuantity(5), 5);
  assert.equal(validateItemQuantity(999), 20);
});
