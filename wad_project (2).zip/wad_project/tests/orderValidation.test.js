const test = require('node:test');
const assert = require('node:assert/strict');

const VALID_STATUSES = ['PAID', 'PREPARING', 'READY', 'PICKED_UP'];

function canTransition(current, next) {
  const currentIndex = VALID_STATUSES.indexOf(current);
  const nextIndex = VALID_STATUSES.indexOf(next);
  if (currentIndex === -1 || nextIndex === -1) return false;
  return nextIndex === currentIndex + 1;
}

test('OrderLifecycle - Validates sequential state machine transitions', () => {
  assert.equal(canTransition('PAID', 'PREPARING'), true);
  assert.equal(canTransition('PREPARING', 'READY'), true);
  assert.equal(canTransition('READY', 'PICKED_UP'), true);
});

test('OrderLifecycle - Disallows backward or skipped state machine transitions', () => {
  assert.equal(canTransition('PAID', 'READY'), false);
  assert.equal(canTransition('READY', 'PAID'), false);
  assert.equal(canTransition('PICKED_UP', 'PREPARING'), false);
});
