const test = require('node:test');
const assert = require('node:assert/strict');
const PriceCalculator = require('../src/services/PriceCalculator.js');

test('PriceCalculator - Cold Coffee base price calculation', () => {
  const base = 40;
  const unit = PriceCalculator.calculateItemUnitPrice(base, []);
  assert.equal(unit, 40);
});

test('PriceCalculator - Cold Coffee with Extra Ice Cream (+15) equals 55', () => {
  const base = 40;
  const unit = PriceCalculator.calculateItemUnitPrice(base, ['Extra Ice Cream (+₹15)']);
  assert.equal(unit, 55);
});

test('PriceCalculator - Cold Coffee with Large Size (+15) and Extra Ice Cream (+15) equals 70', () => {
  const base = 40;
  const unit = PriceCalculator.calculateItemUnitPrice(base, ['Large Size (+₹15)', 'Extra Ice Cream (+₹15)']);
  assert.equal(unit, 70);
});

test('PriceCalculator - Samosa base price equals 15', () => {
  const base = 15;
  const unit = PriceCalculator.calculateItemUnitPrice(base, []);
  assert.equal(unit, 15);
});

test('PriceCalculator - Samosa with Extra Cheese (+15) equals 30', () => {
  const base = 15;
  const unit = PriceCalculator.calculateItemUnitPrice(base, ['Extra Cheese (+₹15)']);
  assert.equal(unit, 30);
});

test('PriceCalculator - Free customizations do not alter price', () => {
  const base = 35; // Veg Sandwich
  const unit = PriceCalculator.calculateItemUnitPrice(base, ['Less Spicy', 'Less Sugar']);
  assert.equal(unit, 35);
});

test('PriceCalculator - Full cart subtotal calculation matches scenario (Cold Coffee 55 + Samosa 15 = 70)', () => {
  const items = [
    { name: 'Cold Coffee', unitPrice: 55, qty: 1 },
    { name: 'Samosa', unitPrice: 15, qty: 1 }
  ];
  const { subtotal, grandTotal } = PriceCalculator.calculateCartTotals(items, false);
  assert.equal(subtotal, 70);
  assert.equal(grandTotal, 70);
});

test('PriceCalculator - Takeaway packaging adds 5 rupees fee', () => {
  const items = [
    { name: 'Masala Maggi', unitPrice: 35, qty: 2 }
  ];
  const { subtotal, packagingFee, grandTotal } = PriceCalculator.calculateCartTotals(items, true);
  assert.equal(subtotal, 70);
  assert.equal(packagingFee, 5);
  assert.equal(grandTotal, 75);
});
