const test = require('node:test');
const assert = require('node:assert/strict');

function formatToken(counter) {
  const num = Math.max(1, parseInt(counter, 10) || 1);
  return `#B-${String(num).padStart(3, '0')}`;
}

function isValidTokenFormat(token) {
  if (typeof token !== 'string') return false;
  return /^#?B-\d{3,}$/i.test(token.trim());
}

test('TokenGenerator - Generates sequential format #B-001 for count 1', () => {
  const token = formatToken(1);
  assert.equal(token, '#B-001');
  assert.equal(isValidTokenFormat(token), true);
});

test('TokenGenerator - Correctly pads three digits for #B-042', () => {
  const token = formatToken(42);
  assert.equal(token, '#B-042');
  assert.equal(isValidTokenFormat(token), true);
});

test('TokenGenerator - Formats correctly past 100 as #B-105', () => {
  const token = formatToken(105);
  assert.equal(token, '#B-105');
  assert.equal(isValidTokenFormat(token), true);
});

test('TokenGenerator - Validates legitimate tokens and rejects invalid formats', () => {
  assert.equal(isValidTokenFormat('#B-001'), true);
  assert.equal(isValidTokenFormat('B-035'), true);
  assert.equal(isValidTokenFormat('#C-001'), false);
  assert.equal(isValidTokenFormat('12345'), false);
  assert.equal(isValidTokenFormat(''), false);
  assert.equal(isValidTokenFormat(null), false);
});
