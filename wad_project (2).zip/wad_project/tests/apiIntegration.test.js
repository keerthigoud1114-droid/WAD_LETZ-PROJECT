const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const app = require('../server.js');

let server;
let baseUrl;

test.before((t, done) => {
  server = app.listen(0, () => {
    const port = server.address().port;
    baseUrl = `http://localhost:${port}`;
    done();
  });
});

test.after((t, done) => {
  server.close(done);
});

test('API - Health check returns ok', (t, done) => {
  http.get(`${baseUrl}/api/health`, (res) => {
    assert.equal(res.statusCode, 200);
    let data = '';
    res.on('data', c => data += c);
    res.on('end', () => {
      const json = JSON.parse(data);
      assert.equal(json.status, 'ok');
      done();
    });
  });
});

test('API - Server-side order total validation accepts correct total', (t, done) => {
  const payload = JSON.stringify({
    items: [
      { id: 'cold-coffee', name: 'Cold Coffee', qty: 1, customizations: ['Extra Ice Cream (+₹15)'] },
      { id: 'samosa', name: 'Samosa', qty: 1, customizations: [] }
    ],
    takeaway: false,
    slot: 'Immediate',
    paymentMethod: 'upi',
    submittedTotal: 70
  });

  const req = http.request(`${baseUrl}/api/orders`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(payload)
    }
  }, (res) => {
    assert.equal(res.statusCode, 201);
    let data = '';
    res.on('data', c => data += c);
    res.on('end', () => {
      const json = JSON.parse(data);
      assert.equal(json.success, true);
      assert.equal(json.order.grandTotal, 70);
      assert.match(json.order.token, /^#B-\d{3,}$/);
      done();
    });
  });

  req.write(payload);
  req.end();
});

test('API - Server-side validation rejects tampered total', (t, done) => {
  const payload = JSON.stringify({
    items: [
      { id: 'cold-coffee', name: 'Cold Coffee', qty: 1, customizations: ['Extra Ice Cream (+₹15)'] }
    ],
    submittedTotal: 10 // Tampered price (actual is 55)
  });

  const req = http.request(`${baseUrl}/api/orders`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(payload)
    }
  }, (res) => {
    assert.equal(res.statusCode, 400);
    let data = '';
    res.on('data', c => data += c);
    res.on('end', () => {
      const json = JSON.parse(data);
      assert.equal(json.success, false);
      assert.match(json.error, /integrity check failed/i);
      done();
    });
  });

  req.write(payload);
  req.end();
});
